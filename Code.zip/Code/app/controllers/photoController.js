const Photo = require('../models/photo');
const path = require('path');

// Contrôleur pour afficher le formulaire d'upload de photos
exports.getUploadForm = (req, res) => {
  res.render('upload-form');
};

// Contrôleur pour l'upload de photos
exports.uploadPhoto = async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ message: 'Aucun fichier n\'a été téléchargé.' });
    }

    const { description, motsCles } = req.body;

    const newPhoto = new Photo({
      description,
      cheminFichier: path.relative('public', req.file.path),
      motsCles: motsCles.split(','),
    });

    await newPhoto.save();

    return res.status(201).json({ message: 'Photo téléchargée avec succès.' });
  } catch (error) {
    console.error('Erreur lors de l\'upload de la photo :', error);
    return res.status(500).json({ message: 'Erreur lors de l\'upload de la photo.' });
  }
};

// Contrôleur pour la visualisation d'une photo individuelle
exports.getPhoto = async (req, res) => {
  try {
    const { photoId } = req.params;
    const photo = await Photo.findById(photoId);

    if (!photo) {
      return res.status(404).json({ message: 'Photo non trouvée.' });
    }

    res.render('detail', { photo }); // Rend la vue detail.pug avec les détails de la photo
  } catch (error) {
    console.error('Erreur lors de la récupération de la photo :', error);
    return res.status(500).json({ message: 'Erreur lors de la récupération de la photo.' });
  }
};

// Contrôleur pour la mise à jour des informations d'une photo
exports.updatePhoto = async (req, res) => {
  try {
    const { photoId } = req.params;
    const { description, motsCles } = req.body;

    const photo = await Photo.findById(photoId);

    if (!photo) {
      return res.status(404).json({ message: 'Photo non trouvée.' });
    }

    photo.description = description;
    photo.motsCles = motsCles.split(',');

    await photo.save();

    return res.status(200).json({ message: 'Informations de la photo mises à jour avec succès.' });
  } catch (error) {
    console.error('Erreur lors de la mise à jour de la photo :', error);
    return res.status(500).json({ message: 'Erreur lors de la mise à jour de la photo.' });
  }
};

// Contrôleur pour la suppression d'une photo
exports.deletePhoto = async (req, res) => {
  try {
    const { photoId } = req.params;
    const photo = await Photo.findById(photoId);

    if (!photo) {
      return res.status(404).json({ message: 'Photo non trouvée.' });
    }

    await photo.remove();

    return res.status(200).json({ message: 'Photo supprimée avec succès.' });
  } catch (error) {
    console.error('Erreur lors de la suppression de la photo :', error);
    return res.status(500).json({ message: 'Erreur lors de la suppression de la photo.' });
  }
};

// Contrôleur pour la recherche de photos par mots-clés
exports.searchPhotos = async (req, res) => {
  try {
    const { keyword } = req.query;
    const keywords = keyword.split(',');

    const photos = await Photo.find({ motsCles: { $in: keywords } });

    return res.status(200).json(photos);
  } catch (error) {
    console.error('Erreur lors de la recherche de photos :', error);
    return res.status(500).json({ message: 'Erreur lors de la recherche de photos.' });
  }
};

// Contrôleur pour afficher la galerie de photos
exports.getGallery = async (req, res) => {
  try {
    // Logique pour récupérer les photos à afficher dans la galerie
    const photos = await Photo.find(); // Vous devrez adapter cette requête à votre modèle de données

    // Rendre la vue de la galerie avec les données des photos
    res.render('galerie', { photos });
  } catch (error) {
    console.error('Erreur lors de la récupération des photos pour la galerie :', error);
    return res.status(500).json({ message: 'Erreur lors de la récupération des photos pour la galerie.' });
  }
};